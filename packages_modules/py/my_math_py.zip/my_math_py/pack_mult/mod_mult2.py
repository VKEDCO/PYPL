import mod_constants

def mult2(x, y): return x * y

## function that prints module's info.
def info():
    print 'This is mod_mult2 module of ',\
          mod_constants.app_name, 'application ',\
          ' version ', mod_constants.version




