import mod_constants

def mult3(x, y, z): return x * y * z

## function that prints module's info.
def info():
    print 'This is mod_mult3 module of ', \
          mod_constants.app_name, ' application '\
          ' version ', mod_constants.version
