import mod_constants

def subt2(x, y): return x - y

def info():
    print 'This is mod_subt2 module from of', \
          mod_constants.app_name, \
          ' version ', mod_constants.version



