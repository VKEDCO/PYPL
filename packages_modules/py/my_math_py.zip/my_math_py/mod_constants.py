version         = 1.0
app_name        = "My Math"
company_name    = "XYZ, LLC"

