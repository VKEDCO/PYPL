#!/usr/bin/python


## change these paths accordingly.
background_image_fp = 'background_004.jpg'
mouse_image_fp      = 'rus_uzor.png'

import pygame
from pygame.locals import *
from sys import exit

pygame.init()

## screen is a Surface object
## the second parameter is flags (0 means None, in tihs case)
## 32 is depth - number of bits used to store colors
screen = pygame.display.set_mode((225, 225), 0, 32)
pygame.display.set_caption("Hello, PyGame!")

## convert the image to the display's format
background_img = pygame.image.load(background_image_fp).convert()
## since mouse_image_fp is a PNG we should use convert_alpha() to deal
## with alpha component
mouse_cursor_img = pygame.image.load(mouse_image_fp).convert_alpha()

while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            del background_img
            del mouse_cursor_img
            pygame.display.quit()
            exit(0)

    ## blitting is copying from one image to another
    screen.blit(background_img, (0, 0))

    x, y = pygame.mouse.get_pos()
    x -= mouse_cursor_img.get_width() / 2
    y -= mouse_cursor_img.get_height() / 2
    screen.blit(mouse_cursor_img, (x, y))

    ## update the display from the buffer to minimize the flicker
    pygame.display.update()

